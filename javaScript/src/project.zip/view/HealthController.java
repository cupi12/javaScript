package project.view;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import project.model.HealthDAO;
import project.model.HealthDO;

public class HealthController implements Initializable {
	@FXML
	TextField txtname;
	@FXML
	TextField txtphoneNum;
	@FXML
	TextField txtgender;
	@FXML
	TextField txtdivision;
	@FXML
	TextField txtbirth;
	@FXML
	TextField txtfindname;
	@FXML
	TextField txtgrade;
	@FXML
	TextField txtmonth;
	@FXML
	TextField txtdate;
	@FXML
	TextField txtmoney;
	@FXML
	TextField txtcard;
	@FXML
	TextField txttotal;

	HealthDO health = new HealthDO();
	HealthDAO dao = new HealthDAO();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	@FXML
	public void HealthInsert(ActionEvent actionEvent) {// 입력
		health.setName(txtname.getText());
		health.setPhoneNum(txtphoneNum.getText());
		health.setGender(txtgender.getText());
		health.setDivision(txtdivision.getText());
		health.setBirth(txtbirth.getText());
		health.setMoney(txtmoney.getText());
		health.setCard(txtcard.getText());
		health.setTotal(txttotal.getText());

		HealthDAO dao = new HealthDAO();
		dao.insertHealthEmp(health);
		System.out.println("회원 추가 완료");
	}// end of healthinsert

	@FXML
	public void select(ActionEvent actionEvent) {// 한건 회원조회
		health.setName(txtfindname.getText());
		HealthDO result = dao.selectOne(health);
		txtname.setText(result.getName());
		txtphoneNum.setText(result.getPhoneNum());
		txtgender.setText(result.getGender());
		txtdivision.setText(result.getDivision());
		txtbirth.setText(result.getBirth());
		txtmoney.setText(result.getMoney());
		txtcard.setText(result.getCard());
		txttotal.setText(result.getTotal());

		System.out.println("조회 처리완료!");
	}

	@FXML
	public void submit(ActionEvent actionEvent) {// 결제승인

		health.setTotal(txtmoney.getText());
		String sMoney;

		if (txtmoney.getText() == null || txtmoney.getText().isEmpty()) {
			sMoney = txtcard.getText();
		} else {
			sMoney = txtmoney.getText();
		}
		double tMoney = Integer.parseInt(sMoney);
		tMoney = (tMoney * 0.9);		
//		int tCard = Integer.parseInt(sCard);

		txttotal.setText(Double.toString(tMoney));
//		double tTotal = Integer.parseInt(sTotal);

		System.out.println("결제 처리 완료!");
	}

	public void delete(ActionEvent actionEvent) {
		String delName = txtfindname.getText();

		dao.delHelthEmp(delName);
		System.out.println("회원 삭제 완료");
	}

	public void selectAll(ActionEvent actionEvnet) throws IOException {
		Stage stage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("people.fxml"));
		Scene scene = new Scene(root, 600, 600);
		stage.setTitle("헬창 전체회원");
		stage.setScene(scene);
		stage.show();
	}
}
